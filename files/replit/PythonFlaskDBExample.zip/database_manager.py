import sqlite3
from person import Person

class DatabaseManager:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.create_table()

    def create_table(self):
        query = """CREATE TABLE IF NOT EXISTS people (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    age INTEGER NOT NULL
                   )"""
        self.conn.execute(query)
        self.conn.commit()

    def create_person(self, person):
      query = "INSERT INTO people (name, age) VALUES (?, ?)"
      cursor = self.conn.cursor()
      cursor.execute(query, (person.name, person.age))
      self.conn.commit()
      return cursor.lastrowid


    def read_person(self, person_id):
        query = "SELECT * FROM people WHERE id = ?"
        cur = self.conn.cursor()
        cur.execute(query, (person_id,))
        row = cur.fetchone()
        if row:
            return Person(*row)
        return None

    def update_person(self, person):
        query = "UPDATE people SET name = ?, age = ? WHERE id = ?"
        self.conn.execute(query, (person.name, person.age, person.id))
        self.conn.commit()

    def delete_person(self, person_id):
        query = "DELETE FROM people WHERE id = ?"
        self.conn.execute(query, (person_id,))
        self.conn.commit()

    def close(self):
        self.conn.close()
