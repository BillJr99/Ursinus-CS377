from flask import Flask, request, jsonify
from person import Person
from database_manager import DatabaseManager

app = Flask(__name__)
db_manager = DatabaseManager("people.db")

@app.route('/person', methods=['POST'])
def create_person():
    data = request.json
    person = Person(id=None, name=data['name'], age=data['age'])
    person_id = db_manager.create_person(person)
    return jsonify({"id": person_id}), 201

@app.route('/person/<int:person_id>', methods=['GET'])
def read_person(person_id):
    person = db_manager.read_person(person_id)
    if person:
        return jsonify(person.to_dict()), 200
    return jsonify({"error": "Person not found"}), 404

@app.route('/person/<int:person_id>', methods=['PUT'])
def update_person(person_id):
    data = request.json
    person = Person(id=person_id, name=data['name'], age=data['age'])
    db_manager.update_person(person)
    return jsonify({"message": "Person updated"}), 200

@app.route('/person/<int:person_id>', methods=['DELETE'])
def delete_person(person_id):
    db_manager.delete_person(person_id)
    return jsonify({"message": "Person deleted"}), 200

if __name__ == '__main__':
    app.run(debug=True, threaded=False)

# curl -X POST http://localhost:5000/person -H 'Content-Type: application/json' -d '{"name": "John Doe", "age": 30}'

# curl http://localhost:5000/person/1

# curl -X PUT http://localhost:5000/person/1 -H 'Content-Type: application/json' -d '{"name": "Jane Doe", "age": 32}'

# curl -X DELETE http://localhost:5000/person/1
