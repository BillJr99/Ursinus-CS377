import numpy as np
from scipy.sparse import csr_matrix


def convert_to_adj_list(row_indices, col_indices):
  adj_list = {}
  for u, v in zip(row_indices, col_indices):
    if u not in adj_list:
      adj_list[u] = []
    adj_list[u].append(v)
  return adj_list


def dfs(graph, start, visited=None):
  if visited is None:
    visited = set()
  visited.add(start)

  # Iterate over the neighbors of the current node
  for neighbor in graph[start].nonzero()[1]:
    if neighbor not in visited:
      dfs(graph, neighbor, visited)
  return visited


# Define the edges of the graph
edges = [(0, 1), (0, 2), (1, 2), (1, 3)]

# Create the corresponding CSR matrix
num_nodes = max(max(u, v) for u, v in edges) + 1
data = np.ones(len(edges) * 2)  # non-zero edge weights
row_indices = np.array([u for u, v in edges] + [v for u, v in edges])
col_indices = np.array([v for u, v in edges] + [u for u, v in edges])
graph_csr = csr_matrix((data, (row_indices, col_indices)),
                       shape=(num_nodes, num_nodes))

print(graph_csr)

# row_indices[0] and col_indices[0] are the vertices of the first edge in graph_csr with weight data[0]
print(row_indices)
print(col_indices)

# Perform DFS starting from node 0
visited_nodes = dfs(graph_csr, 0)
print("Visited nodes:", visited_nodes)

# Perform DFS on the raw CSR starting from node 0
adj_list = convert_to_adj_list(row_indices, col_indices)
print("Adjacency List:", adj_list)
