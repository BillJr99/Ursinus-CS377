import numpy as np
from scipy.sparse import csr_matrix


def csr_to_weighted_adjacency(csr_matrix):
  """
  Suppose we have a 3x3 sparse matrix represented in CSR format with:

  indptr = [0, 2, 4, 7]
  indices = [0, 2, 1, 2, 0, 1, 2]
  data = [1, 2, 3, 4, 5, 6, 7]

  This corresponds to the following matrix:

  Row	0	1	2
  0	1	0	2
  1	0	3	4
  2	5	6	7

  Here, indptr indicates the start and end of each row in indices and data:

  For row 0: indices[0:2] = [0, 2] and data[0:2] = [1, 2]
  For row 1: indices[2:4] = [1, 2] and data[2:4] = [3, 4]
  For row 2: indices[4:7] = [0, 1, 2] and data[4:7] = [5, 6, 7]

  ... because indptr indicates 0-2, 2-4, and 4-7 are relevant from indices and data for rows 0, 1, and 2 respectively.
  For row 0, indices[0:2] = [0, 2], so row 0 has nonzero entries at columns 0 and 2.  The values are data[0:2] = 1, 2, for a row 0 of [1, 0, 2]: place data[0] in row 0, column indices[0], and data[1] in row 0, column indices[1]
  Repeat for each row (3 and 4 go in positions 1 and 2 of row 1)
  """
  # Extract CSR components
  values = csr_matrix.data
  row_ptr = csr_matrix.indptr
  col_ind = csr_matrix.indices

  # Determine the size of the matrix
  num_rows = csr_matrix.shape[0]
  num_cols = csr_matrix.shape[1]

  # Create an empty adjacency matrix
  adjacency_matrix = np.zeros((num_rows, num_cols), dtype=float)

  # Iterate through each row
  for i in range(num_rows):
    # Extract the start and end indices of the current row
    start_index = row_ptr[i]
    end_index = row_ptr[i + 1]

    # Iterate through each non-zero element in the row
    for j in range(start_index, end_index):
      # Set the corresponding element in the adjacency matrix to the weight
      adjacency_matrix[i, col_ind[j]] = values[j]

  return adjacency_matrix


def convert_to_adj_list(row_indices, col_indices):
  adj_list = {}
  for u, v in zip(row_indices, col_indices):
    if u not in adj_list:
      adj_list[u] = []
    adj_list[u].append(v)
  return adj_list


def dfs(graph, start, visited=None):
  if visited is None:
    visited = set()
  visited.add(start)

  # Iterate over the neighbors of the current node
  for neighbor in graph[start].nonzero()[1]:
    if neighbor not in visited:
      dfs(graph, neighbor, visited)
  return visited


# Define the edges of the graph
edges = [(0, 1), (0, 2), (1, 2), (1, 3)]

# Create the corresponding CSR matrix
num_nodes = max(max(u, v) for u, v in edges) + 1
data = np.ones(len(edges) * 2)  # non-zero edge weights
row_indices = np.array([u for u, v in edges] + [v for u, v in edges])
col_indices = np.array([v for u, v in edges] + [u for u, v in edges])
graph_csr = csr_matrix((data, (row_indices, col_indices)),
                       shape=(num_nodes, num_nodes))

print(graph_csr)

# row_indices[0] and col_indices[0] are the vertices of the first edge in graph_csr with weight data[0]
print(row_indices)
print(col_indices)

# Perform DFS starting from node 0
visited_nodes = dfs(graph_csr, 0)
print("Visited nodes:", visited_nodes)

# Convert to an adjacency list
adj_list = convert_to_adj_list(row_indices, col_indices)
print("Adjacency List:", adj_list)

# Convert to an adjacency matrix
adj_matrix = csr_to_weighted_adjacency(graph_csr)
print("Row indices (indptr):", graph_csr.indptr)
print("Col indices (indices):", graph_csr.indices)
print("Adjacency Matrix:", adj_matrix)
