import os
import redis
from redisgraph import Node, Edge, Graph
from graphviz import Source

def convert_dotty_to_png(dotty_file):
  """ Convert a Dotty file to a PNG file. """
  with open(dotty_file) as f:
      dot_graph = f.read()
  
  src = Source(dot_graph, format='png')
  src.render(dotty_file, view=False)
  
def redis_graph_to_dotty(graph):
  # Query to retrieve all nodes and relationships
  query = "MATCH (n) OPTIONAL MATCH (n)-[r]->(m) RETURN n,r,m"
  result = graph.query(query)

  # Initialize Dotty representation
  dotty = "digraph G {\n"

  # Track nodes using their IDs to avoid duplication
  nodes_added = set()

  # Process query results
  for record in result.result_set:
      start_node, relationship, end_node = record

      # Add nodes
      if start_node.id not in nodes_added:
          dotty += f'"{start_node.id}" [label="{start_node.properties.get("description", start_node.id)}"];\n'
          nodes_added.add(start_node.id)
      if end_node and end_node.id not in nodes_added:
          dotty += f'"{end_node.id}" [label="{end_node.properties.get("description", end_node.id)}"];\n'
          nodes_added.add(end_node.id)

      # Add edge
      if relationship:
          dotty += f'"{start_node.id}" -> "{end_node.id}" [label="{relationship.relation}"];\n'

  dotty += "}"

  return dotty
  
# https://dev.to/ramko9999/host-and-use-redis-for-free-51if
# https://github.com/RedisGraph/redisgraph-py
# https://www.redislabs.com

# Create free subscription with cloud vendor of choice
# Create database with Redis and Graph capabilities
# Set host, url, port, and database name used

# control-shift-S to launch repl.it shell and set these variables
password = os.environ.get('DBPASSWORD');
dbname = "RedisGraph"
url = "redis-10772.c259.us-central1-2.gce.cloud.redislabs.com"
port = 10772

redisdb = redis.Redis(host=url, port=port, password=password)
graph = Graph('social', redisdb)

# Reinitialize
redisdb.flushdb() # also redisdb.delete(keyname)

kphl = Node(label="airport", properties={"description": "Philadelphia International Airport"})
kmco = Node(label="airport", properties={"description": "Orlando International Airport"})
kbwi = Node(label="airport", properties={"description": "Thurgood Marshall Baltimore Washington International Airport"})
kabq = Node(label="airport", properties={"description": "Albuquerque International Sunport"})
kbos = Node(label="airport", properties={"description": "Boston International Sunport"})

graph.add_node(kphl)
graph.add_node(kmco)
graph.add_node(kbwi)
graph.add_node(kabq)
graph.add_node(kbos)

route1 = Edge(kphl, 'direct', kmco)
route2 = Edge(kmco, 'direct', kabq)
route3 = Edge(kbwi, 'direct', kabq)
route4 = Edge(kphl, 'direct', kbos)
route5 = Edge(kbos, 'direct', kbwi)

graph.add_edge(route1)
graph.add_edge(route2)
graph.add_edge(route3)
graph.add_edge(route4)
graph.add_edge(route5)

graph.commit()

# Direct routes
query1 = """MATCH (a:airport)-[d1:direct]->(b:airport) RETURN a.description, b.description"""
result = graph.query(query1)
print(result.result_set)
for row in result.result_set:
  departure = row[0]
  destination = row[1]
  print("I can go from " + departure + " to " + destination)
graph.query(query1).pretty_print()

# One layover routes from PHL to ABQ
query2 = """MATCH (a:airport)-[d1:direct]->(b:airport)-[d2:direct]->(c:airport) WHERE a.description = 'Philadelphia International Airport' AND c.description = 'Albuquerque International Sunport' RETURN a.description, b.description, c.description"""
graph.query(query2).pretty_print()

# Transitive closure for all routes from PHL to ABQ regardless of the number of layovers
# Can limit number of layovers with [:direct*1..3]
query2 = """MATCH path = (start:airport {description: 'Philadelphia International Airport'})-[:direct*]->(end:airport {description: 'Albuquerque International Sunport'}) RETURN [node in nodes(path) | node.description] AS descriptions"""
graph.query(query2).pretty_print()

# Export to dotty
dotty = redis_graph_to_dotty(graph)
print(dotty)
f = open('graph.dot', 'w')
f.write(dotty)
f.close()
convert_dotty_to_png('graph.dot')