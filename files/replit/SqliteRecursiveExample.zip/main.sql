-- Table for storing person information
CREATE TABLE Person (
    PersonID INTEGER PRIMARY KEY,
    FirstName TEXT,
    LastName TEXT,
    DateOfBirth DATE
);

-- Table for mapping parent to child
CREATE TABLE ParentChild (
    ParentID INTEGER,
    ChildID INTEGER,
    FOREIGN KEY (ParentID) REFERENCES Person (PersonID),
    FOREIGN KEY (ChildID) REFERENCES Person (PersonID)
);

INSERT INTO Person (FirstName, LastName, DateOfBirth) VALUES ('Bob', 'Smith', '1960-01-01');
INSERT INTO Person (FirstName, LastName, DateOfBirth) VALUES ('Alice', 'Jones', '1990-02-01');
INSERT INTO Person (FirstName, LastName, DateOfBirth) VALUES ('Eve', 'Brown', '1990-03-01');
INSERT INTO Person (FirstName, LastName, DateOfBirth) VALUES ('Dave', 'White', '2010-04-01');

INSERT INTO ParentChild (ParentID, ChildID) VALUES (1, 2);
INSERT INTO ParentChild (ParentID, ChildID) VALUES (1, 3);
INSERT INTO ParentChild (ParentID, ChildID) VALUES (3, 4);

INSERT INTO Person(FirstName, LastName, DateOfBirth) VALUES ('Jane', 'Richardson', '1960-01-01');
INSERT INTO Person(FirstName, LastName, DateOfBirth) VALUES ('Jack', 'Richardson', '1985-01-01');

INSERT INTO ParentChild (ParentID, ChildID) VALUES (5, 6);

-- We assume the function ancestor_id returns the ID of the ancestor we want to start with.
-- For example, let's find the family tree starting from Bob Smith (PersonID = 1).
WITH RECURSIVE FamilyTree AS (
  -- Anchor member: select the person who is the specified ancestor
  SELECT
      p.PersonID,
      p.FirstName,
      p.LastName,
      p.DateOfBirth,
      CAST('' AS TEXT) as Indent,  -- This is used for visual indentation
      0 as Generation
  FROM Person AS p
  WHERE p.PersonID = 1  -- Specify the ancestor's PersonID here
  UNION ALL
  -- Recursive member: select the descendants
  SELECT
      p.PersonID,
      p.FirstName,
      p.LastName,
      p.DateOfBirth,
      ft.Indent || '  ' as Indent,  -- Increase the indentation for each generation
      ft.Generation + 1 as Generation
  FROM Person AS p
  JOIN ParentChild AS pc ON p.PersonID = pc.ChildID
  JOIN FamilyTree AS ft ON pc.ParentID = ft.PersonID
)

SELECT Indent || FirstName || ' ' || LastName AS Name, Generation FROM FamilyTree
ORDER BY Generation, Name;  -- This will order by generation and then by name alphabetically